<?php
    session_start();
    require_once("modelo.php");
    eliminarMaterial();
    
?>