<?php
    session_start();
    require_once("modelo.php");
    if(isset($_SESSION["usuario"]) ) {
        if((isset($_POST["nMail"]) != NULL) && (isset($_POST["cMail"]) != NULL)) {
            if ($_POST["nMail"] === $_POST["cMail"]) {
                modificarCorreo($_POST["id"], $_POST["nMail"]);
                header("location: perfil.php?idPage=7&exitoMail=1");
            }
            else {
                header("location: perfil.php?idPage=7&errorMail=1");
        }
        }
    } else {
        header("location:indexLogin.php?idPage=0");
    }
?>