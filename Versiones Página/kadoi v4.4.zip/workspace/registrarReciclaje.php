<?php
    session_start();
    require_once("modelo.php");
    if(isset($_SESSION["usuario"]) ) {
        if((isset($_POST["insti"]) != NULL) && (isset($_POST["mater"]) != NULL) && (isset($_POST["canti"]) != NULL)) {
            unset($_SESSION["error_edicion"]);
            registrarReciclaje($_POST["insti"], $_POST["mater"], $_POST["canti"]);
            header("location:indexLogin.php?idPage=0");
        } else {
            $_SESSION["error_edicion"] = "No se pudo completar el cambio";
            header("location:indexLogin.php?idPage=0");
        }
    } else {
        header("location:indexLogin.php?idPage=0");
    }
?>