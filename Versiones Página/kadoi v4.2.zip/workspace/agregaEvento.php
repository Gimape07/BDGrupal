<?php

session_start();
require_once("modelo.php");
$user=$_SESSION["usuario"];

agregaEvento();


header("location:evento.php");



?>