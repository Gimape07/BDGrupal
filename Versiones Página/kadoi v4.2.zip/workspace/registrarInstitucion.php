<?php
    session_start();
    require_once("modelo.php");
    if(isset($_SESSION["usuario"]) ) {
        if((isset($_POST["rfc"]) != NULL) && (isset($_POST["rs"]) != NULL) && (isset($_POST["desc"]) != NULL) && (isset($_POST["est"]) != NULL) && (isset($_POST["cp"]) != NULL)) {
            unset($_SESSION["error_edicion"]);
            registrarInstitucion($_POST["rfc"], $_POST["rs"], $_POST["desc"], $_POST["est"], $_POST["cp"]);
            header("location:instituciones.php?idPage=1");
        } else {
            $_SESSION["error_edicion"] = "No se pudo completar el cambio";
            header("location:instituciones.php?idPage=1");
        }
    } else {
        header("location:indexLogin.php?idPage=0");
    }
?>