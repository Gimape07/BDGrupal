/*******************************************
*Legión ISRA
*Abraham Lemus
*Armando Ruiz
*Giancarlo Marte
*Algoritmo de interpolación
*******************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define n 3

int main(){

    double X[]={1,5,20};
    double Y[]={56.5,113,181};
    double a[n][n];
    double x[n];
    int i,j,k,l,m,p;
    double suma;
    double value, res;
    for(i=0; i<n; i++){
        for(j=0;j<n;j++){
            a[i][j]= pow(X[i],j);
        }
    }
    //aki sha llena la matriz de koeficentes

    for(i=0; i<n; i++){
        for(j=0;j<n;j++){
            printf("%lf ", a[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    double piv;
    for(l=0;l<n-1;l++){
        for(m=l+1;m<n;m++){
            piv = a[m][l]/a[l][l];
            for(p=l;p<n;p++){
                a[m][p]=a[m][p]- piv*a[l][p];
            }
            Y[m]=Y[m]- piv* Y[l];
        }
    }
    //**********************************************
    for(i = 0; i < n; i++){
        for (j = 0; j < n; j++){
            printf("%lf ", a[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    //***********************************************
    x[n-1] = Y[n-1]/a[n-1][n-1];

    for(i = n-2; i >= 0; --i){
        suma = Y[i];
        for(j = i+1; j<n; j++){
            suma -= a[i][j]*x[j];
        }
        x[i] = suma/a[i][i];
    }
    printf("\n");
    for (i=0;i<n;i++){
        printf("%lf\n", x[i]);
    }

    printf("\n");

    for(i=0;i<n;i++){
        if(i==n-1){
            printf("%lf * X^%i", x[i], i);
        }
        else if(i==0){
            printf(" Y = %lf + ", x[i]);
        }
        else {
            printf("%lf * X^%i + ", x[i], i);
        }

    }

    printf("\n\n");

    printf("Ingresa el valor de X a evaluar: ");
    scanf("%lf", &value);

    res = 0;

    for(i=0; i<n; i++){
            res += x[i]*pow(value,i);
    }
    
    
    printf("\n\n");

    printf("%lf", res);
    
    
    printf("\n\n");

    return 0;
}
