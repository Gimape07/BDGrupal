<?php

session_start();
require_once("modelo.php");
$user=$_SESSION["usuario"];

agregaMaterial();


header("location:materiales.php");



?>