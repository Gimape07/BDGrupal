<?php
    $name = "kadoi";
    $url = "https://daw-bd-diagsrmd.c9users.io/Service_Lab24/public/index.php"; //Route to the REST web service
    $c = curl_init($url);
    $response = curl_exec($c);
    curl_close($c);
    //var_dump($response); 
?>