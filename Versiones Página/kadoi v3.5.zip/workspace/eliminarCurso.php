<?php
    session_start();
    require_once("hockey_pack.php");
    if(isset($_SESSION["usuario"]) ) {
        if(isset($_GET["id"]) != NULL ) {
            unset($_SESSION["error_delete"]);
            eliminarCurso($_GET["id"]);
            header("location:cursos.php?idPage=5&cPage=1");
        } else {
            $_SESSION["error_delete"] = "No se pudo completar el cambio";
            header("location:cursos.php?idPage=5&cPage=1");
        }
    } else {
        header("location:indexLogin.php");
    }
?>