<?php
    session_start();
    require_once("modelo.php");
    if(isset($_SESSION["usuario"]) ) {
        if((isset($_POST["nPass"]) != NULL) && (isset($_POST["cPass"]) != NULL)) {
            if ($_POST["nPass"] === $_POST["cPass"]) {
                modificarPassword($_POST["id"], $_POST["nPass"]);
                header("location: perfil.php?idPage=7&exito=1");
            }
            else {
                header("location: perfil.php?idPage=7&error=1");
        }
        }
    } else {
        header("location:indexLogin.php?idPage=0");
    }
?>