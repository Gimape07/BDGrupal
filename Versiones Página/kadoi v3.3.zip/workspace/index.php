<?php
    session_start();
    if(isset($_SESSION["usuario"]) ) {
        header("location: login.php");    
    } else {
        $user = "";
        if (isset($_SESSION["error"]) != ""){
            unset($_SESSION["error"]);    
        }
        if (isset($_SESSION["errorActivo"]) != "") {
            unset($_SESSION["errorActivo"]);   
        }
        if (isset($_SESSION["error_password"]) != "") {
            unset($_SESSION["error_password"]);   
        }
        if (isset($_SESSION["correct_password"]) != "") {
            unset($_SESSION["correct_password"]);   
        }
        include("_header.html");
        include("_cuerpo.html");
        include("_footer.html");
    }
?>