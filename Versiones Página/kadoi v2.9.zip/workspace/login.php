<?php
    session_start();
    require_once("modelo.php");
    
    if(isset($_SESSION["usuario"]) ) {
        $user = $_SESSION["usuario"];
        include("_header.html");
        include("_cuerpo.html");
        include("_footer.html"); 
    }else if (login($_POST["usuario"], $_POST["contraseña"]) || loginRecovery($_POST["usuario"], $_POST["contraseña"])) {
        $usuario = $_POST["usuario"];
        if (getActivo($usuario)) {
            unset($_SESSION["error"]);
            unset($_SESSION["errorActivo"]);
            unset($_SESSION["error_password"]);
            unset($_SESSION["correct_password"]);
            $_SESSION["usuario"] = $_POST["usuario"];
            $user = $_SESSION["usuario"];
            include("_header.html");
            include("_cuerpo.html");
            include("_footer.html");
        }
        else {
            unset($_SESSION["error"]);
            unset($_SESSION["error_password"]);
            unset($_SESSION["correct_password"]);
            $_SESSION["errorActivo"] = "Tu cuenta ha sido suspendida por un administrador";
            header("location: ingresar.php");
        }
    } else {
        unset($_SESSION["errorActivo"]);
        unset($_SESSION["error_password"]);
        unset($_SESSION["correct_password"]);
        $_SESSION["error"] = "Usuario y/o contraseña incorrectos";
        header("location: ingresar.php");
    }
    
?>