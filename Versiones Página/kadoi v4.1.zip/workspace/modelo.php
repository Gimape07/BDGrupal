<?php

    require("vendor/phpmailer/phpmailer/src/PHPMailer.php");
    require("vendor/phpmailer/phpmailer/src/SMTP.php");
    
    function connect() {
        $ENV = "prod";
        if ($ENV == "dev") {
            $mysql = mysqli_connect("localhost","pedro","perez","proyecto");
                                            //root si estan en windows
        } else  if ($ENV == "prod"){
            $mysql = mysqli_connect("localhost","negromancer","","proyecto");
        }
        $mysql->set_charset("utf8");
        return $mysql;
    }
    
    function disconnect($mysql) {
        mysqli_close($mysql);
    }
    
    function login($user, $password) {
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT nUser FROM Usuario WHERE nUser="'.$user.
                '" AND password="'.$password.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
             
            if (mysqli_num_rows($results) > 0)  {
                // it releases the associated results
                mysqli_free_result($results);
                disconnect($db);
                return true;
            }
            return false;
        } 
        return false;
    }
    
    function loginRecovery($user, $password) {
        $db = connect();
        if ($db != NULL) {
            if ($password != NULL)  {
                //Specification of the SQL query
                $query='SELECT nUser FROM Usuario WHERE nUser="'.$user.
                    '" AND recovery_pass="'.$password.'"';
                $query;
                 // Query execution; returns identifier of the result group
                $results = $db->query($query);
                 // cycle to explode every line of the results
                 
                if (mysqli_num_rows($results) > 0)  {
                    // it releases the associated results
                    mysqli_free_result($results);
                    disconnect($db);
                    return true;
                }
            }
            disconnect($db);
            return false;
        } 
        return false;
    }
    
    function crearProducto($nombre, $imagen) {
        $db = connect();
        if ($db != NULL) {
            
            // insert command specification 
            $query='INSERT INTO productos (nombre,imagen) VALUES (?,?) ';
            // Preparing the statement 
            if (!($statement = $db->prepare($query))) {
                die("Preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params 
            if (!$statement->bind_param("ss", $nombre, $imagen)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error); 
            }
             // Executing the statement
             if (!$statement->execute()) {
                die("Execution failed: (" . $statement->errno . ") " . $statement->error);
              } 

            
            mysqli_free_result($results);
            disconnect($db);
            return true;
        } 
        return false;
    }
    
    function editarCapsula($titulo, $descripcion, $enlace, $id){
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $query='UPDATE Capsula SET titulo=?, descripcion=?, enlaceCapsula=? WHERE idCapsula=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("ssss", $titulo, $descripcion, $enlace, $id)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function eliminarCapsula($idCapsula){
        $db = connect();
        if ($db != NULL) {
            // Deletion query construction
            $query = 'DELETE FROM Capsula WHERE idCapsula=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $idCapsula)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // delete execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function getTable($tabla) {
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT * FROM '.$tabla;
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
        
           $html = '<table class="striped">';
           $html .= '<thead>';
           $html .= '<tr>';
           $columnas = $results->fetch_fields();
           for($i=0; $i<count($columnas); $i++) {
                $html .= '<th>'.$columnas[$i]->name.'</th>';
           }
           $html .= '</tr>';
           $html .= '</thead>';
           
           $html .= '<tbody>';
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    $html .= '<tr>';
                    for($i=0; $i<count($fila); $i++) {
                        // use of numeric index
                        $html .= '<td>'.$fila[$i].'</td>'; 
                    }
                    $html .= '</tr>';
            }
            $html .= '</tbody></table>';   
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return $html;
        }
        return false;
    }
    
    function getCapsulas($pagina, $user) {
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $total = 6;
            $cantidad = $pagina * $total;
            $i=$cantidad - $total;
            $query='SELECT * FROM Capsula LIMIT '.$i.','.$total.'';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
            $html = '';
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    if($i<$cantidad) {
                        $html .= '<div class="col-md-4">
                                <div class="card mb-4 box-shadow">
                                    <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="'.$fila["enlaceCapsula"].'" allowfullscreen></iframe>
                                    </div>
                                <div class="card-body">
                                    <h5 class="card-title">'.$fila["titulo"].'</h5>
                                    <p class="card-text">'.$fila["descripcion"].'</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="btn-group">';
                                            if(getRol($user) == 1){
                                                $html .= '<a class="btn btn-sm btn-outline-secondary" href="#" data-href="/capsula.php" role="button" data-toggle="modal" data-target="#modCap" data-id="'.$fila["idCapsula"].'" data-titulo="'.$fila["titulo"].'" data-enlace="'.$fila["enlaceCapsula"].'">Editar</a>
                                                <a class="btn btn-sm btn-outline-secondary" role="button" href="#" data-href="/eliminarCapsula.php?id='.$fila["idCapsula"].'" data-toggle="modal" data-target="#confirm-delete" data-whatever="'.$fila["titulo"].'">Eliminar</a>
                                                </div>
                                                <small class="text-muted">'.$fila["fecha"].'</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    ';
                                            }
                                            else {
                                        $html .= '</div>
                                                    <small class="text-muted">'.$fila["fecha"].'</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    ';
                            }
                        // use of numeric index
                    $i++;
                    }
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function getCapsula($idCapsula) {
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT * FROM Capsula WHERE idCapsula='.$idCapsula;
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
            $html = '';
            $fila = mysqli_fetch_array($results, MYSQLI_BOTH);
            $html .= '<div class="col-md-4">
                                <div class="card mb-4 box-shadow">
                                    <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="'.$fila["enlaceCapsula"].'" allowfullscreen></iframe>
                                    </div>
                                <div class="card-body">
                                    <h5 class="card-title">'.$fila["titulo"].'</h5>
                                    <p class="card-text">'.$fila["descripcion"].'</p>
                                    </div>
                                </div>
                            </div>
                            
                            ';
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return true;
    }
    
    
    function agregarCapsula($titulo, $descripcion, $enlaceCapsula) {
        $db = connect();
        if ($db != NULL) {
            // insert command specification 
            $query='INSERT INTO Capsula (titulo, descripcion, enlaceCapsula) VALUES (?,?,?) ';
            // Preparing the statement 
            if (!($statement = $db->prepare($query))) {
                die("Preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params 
            if (!$statement->bind_param("sss", $titulo, $descripcion, $enlaceCapsula)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error); 
            }
             // Executing the statement
             if (!$statement->execute()) {
                die("Execution failed: (" . $statement->errno . ") " . $statement->error);
              }
            
            mysqli_free_result($results);
            disconnect($db);
            return true;
        } 
        return false;
    }
    
    function numeroCapsulas() { //Cuenta el numero de páginas necesarias para cubrir todas las capsulas
        $db = connect();
        if ($db != NULL) {
            $total = 6;
            //Specification of the SQL query
            $query='SELECT * FROM Capsula';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
            $html = 0;
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    $html++;
            }
            $html = ceil($html/$total);
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return $html;
        }
        return false;
    }
    
    function paginationCapsula($numero) {
        $db = connect();
        if ($db != NULL) {
            $html = '';
            $indice = 1;
            $total = 5;
            if($numero > 5) {
                $indice = ($numero - ($total - 1));
                $total = $numero;
            }
            while($indice <= $total) {
                $html .= '<li class="page-item" id="pageC'.$indice.'"><a class="page-link" href="capsula.php?idPage=3&cPage='.$indice.'">'.$indice.'</a></li>';
                $indice++;
            }
            echo $html;
            // it releases the associated results
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function getActivo($user) {
        $db = connect();
        if ($db != NULL) {
            //Specification of the SQL query
            $query='SELECT activo FROM Usuario WHERE nUser="'.$user.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    if($fila["activo"]) {
                        mysqli_free_result($results);
                        disconnect($db);
                        return true;
                    }
            }
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return false;
        }
        return false;
    }
    
    function getValueActivo($user) {
        $db = connect();
        if ($db != NULL) {
            //Specification of the SQL query
            $query='SELECT activo FROM Usuario WHERE nUser="'.$user.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    mysqli_free_result($results);
                    disconnect($db);
                    return $fila["activo"];
            }
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return false;
        }
        return false;
    }
    
    function setActivo($user) {
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $query='UPDATE Usuario SET activo=-1 WHERE nUser=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $user)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function getRol($user){
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT idRol FROM Usuario_Rol WHERE nUser="'.$user.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
            $fila = mysqli_fetch_array($results, MYSQLI_BOTH);
            $rol = $fila["idRol"];
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return $rol;
        }
        return true;
    }
    
    function getNombreRol($rol){
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT nombre FROM Rol WHERE idRol="'.$rol.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
            $fila = mysqli_fetch_array($results, MYSQLI_BOTH);
            $nombre = $fila["nombre"];
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return $nombre;
        }
        return true;
    }
    
    function getUsuario($user){
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT nUser FROM Usuario WHERE nUser="'.$user.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
            $fila = mysqli_fetch_array($results, MYSQLI_BOTH);
            if ($user == $fila["nUser"]){
                mysqli_free_result($results);
                disconnect($db);
                return true;
            }
            else {
                mysqli_free_result($results);
                disconnect($db);
                return false;
            }
        }
        return false;
    }
    
    function getUsuarios(){
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT nUser, idRol FROM Usuario_Rol WHERE idRol!="1"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '<div class="container">
                        <h2>Usuarios Registrados</h2>
                        <p>Listado de usuarios registrados</p>            
                        <table class="table table-striped">
                            <thead>
                                <tr>';
           $columnas = $results->fetch_fields();
           /*
           for($i=0; $i<count($columnas); $i++) {
                $html .= '<th>'.$columnas[$i]->name.'</th>';
           }
           */
           $html .= '<th>ID Usuario</th>';
           $html .= '<th>Rol de Usuario</th>';
           $html .= '<th>Acción</th>';
           $html .= '</tr>';
           $html .= '</thead>';
           $html .= '<tbody>';
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    $html .= '<tr>';
                    $html .= '<td>'.$fila["nUser"].'</td>'; 
                    $html .= '<td>'.getNombreRol($fila["idRol"]).'</td>';
                    if (getActivo($fila["nUser"])){
                        $html .= '<td><a class="btn btn-secondary btn-sm" role="button" href="#" data-href="/sus_act_user.php?id='.$fila["nUser"].'" data-toggle="modal" data-target="#user-suspender" data-whatever="'.$fila["nUser"].'">Suspender</a>   ';
                    }
                    else {
                    $html .= '<td><a class="btn btn-primary btn-sm" role="button" href="#" data-href="/sus_act_user.php?id='.$fila["nUser"].'" data-toggle="modal" data-target="#user-activar" data-whatever="'.$fila["nUser"].'">Activar</a>   ';
                    }
                    $html .= '<a class="btn btn-danger btn-sm" role="button" href="#" data-href="/eliminarUsuario.php?id='.$fila["nUser"].'" data-toggle="modal" data-target="#user-delete" data-whatever="'.$fila["nUser"].'">Eliminar</a>';
                    $html .= '</tr>';
            }
            $html .= '</tbody></table></div>';   
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function suspenderUsuario($idUsuario){
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $query='UPDATE Usuario SET activo=0 WHERE nUser=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $idUsuario)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function activarUsuario($idUsuario){
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $query='UPDATE Usuario SET activo=1 WHERE nUser=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $idUsuario)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function eliminarUsuario2($idUsuario){
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $query='UPDATE Usuario SET activo=0 WHERE nUser=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $idUsuario)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function eliminarUsuario($idUsuario){
        $db = connect();
        if ($db != NULL) {
            // Deletion query construction
            $query = 'DELETE FROM Usuario WHERE nUser=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $idUsuario)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // delete execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function enviarPassword($idUsuario) {
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $query='SELECT email FROM Usuario WHERE nUser="'.$idUsuario.'"';
            $query;
            $results = $db->query($query);
             // cycle to explode every line of the results
            $fila = mysqli_fetch_array($results, MYSQLI_BOTH);
            $mail = $fila["email"];
            
            $password = rand(999, 99999);
            $password_hash = md5($password);
            
            
            $m = new PHPMailer\PHPMailer\PHPMailer();
            $m->IsSMTP(); // enable SMTP
            $m->SMTPAuth = true;
            $m->CharSet = 'UTF-8';
            
            $m->Host = 'smtp.gmail.com';
            $m->Username = 'reciclajeSolidario.online@gmail.com';
            $m->Password = 'reciclajeSolidario.';
            $m->SMTPSecure = 'ssl';
            $m->Port = 465;
            
            $m->From = 'reciclajeSolidario.online@gmail.com';
            $m->FromName = 'Reciclaje Solidario';
            
            $m->addAddress($mail);
            
            $m->Subject = 'Recuperar Contraseña';
            $m->Body = 'Al iniciar sesión ingresa esta nueva contraseña: '. "\n\n" . "$password_hash" . "\n\n\n" . 'Reciclaje Solidario';
            
            $m->send();
            
            
            $query='UPDATE Usuario SET recovery_pass=? WHERE nUser=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("ss", $password_hash, $idUsuario)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function modificarPassword($idUsuario, $password){
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $password = md5($password);
            $query='UPDATE Usuario SET password=?, recovery_pass=NULL WHERE nUser=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("ss", $password, $idUsuario)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function getEvento($idEvento){
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT nombre, idEstado, codigoPostal, descripcion, direccion, fecha FROM Evento WHERE idEvento="'.$idEvento.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '<div class="container">
                        <h2>Consulta de Evento:</h2>
                        <p>Detalles y especificaciones del evento</p>            
                        <br><br>';
           $columnas = $results->fetch_fields();
           /*
           for($i=0; $i<count($columnas); $i++) {
                $html .= '<th>'.$columnas[$i]->name.'</th>';
           }
           */
           $i = 0;
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    for ($i = 0; $i < 6; $i++)  {
                        if ($i == 0){
                            $html .= '<h4>Evento</h4>';
                            $html .= '<h6>'.$fila["nombre"].'<h6>'; 
                            $html .= '<br>'; 
                        }
                        if ($i == 1){
                            $html .= '<h4>Estado</h4>';
                            $html .= '<h6>'.getNombreEstado($fila["idEstado"]).'</h6>';
                            $html .= '<br>'; 
                        }
                        if ($i == 2){
                            $html .= '<h4>Código Postal</h4>';
                            $html .= '<h6>'.$fila["codigoPostal"].'</h6>';
                            $html .= '<br>'; 
                        }
                        if ($i == 3){
                            $html .= '<h4>Dirección</h4>';
                            $html .= '<h6>'.$fila["direccion"].'</h6>';
                            $html .= '<br>'; 
                        }
                        if ($i == 4){
                            $html .= '<h4>Descripción</h4>';
                            $html .= '<h6>'.$fila["descripcion"].'</h6>';
                            $html .= '<br>'; 
                        }
                        if ($i == 5){
                            $html .= '<h4>Fecha</h4>';
                            $html .= '<h6>'.$fila["fecha"].'</h6>';
                            $html .= '<br>'; 
                        }
                    }
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    function getNombreEstado($idEstado){
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT Nombre FROM Estado WHERE idEstado="'.$idEstado.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
            $fila = mysqli_fetch_array($results, MYSQLI_BOTH);
            $nombre = $fila["Nombre"];
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return $nombre;
        }
        return true;
    }
    
    //echo getTable("usuarios");
    //echo getTable("productos");
    
    
    
    function agregaEvento(){
        
        $nombre=$_POST["nombreEvento"];
        $descripcion=$_POST["descripcionEvento"];
        $direccion=$_POST["direccionEvento"];
        $idEstado=$_POST["idEstado"];
        $cp=$_POST["cpEvento"];
        $fecha=$_POST["fechaEvento"];
        
        $db = connect();
        if ($db != NULL) {
            // insert command specification 
            $query='INSERT INTO Evento (nombre, idEstado, codigoPostal, descripcion, direccion, fecha) VALUES (?,?,?,?,?,?) ';
            // Preparing the statement 
            if (!($statement = $db->prepare($query))) {
                die("Preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params 
            if (!$statement->bind_param("ssssss", $nombre, $idEstado, $cp, $descripcion, $direccion, $fecha)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error); 
            }
             // Executing the statement
             if (!$statement->execute()) {
                die("Execution failed: (" . $statement->errno . ") " . $statement->error);
              }
            
            mysqli_free_result($results);
            disconnect($db);
            return true;
        } 
        return false;
    }
    
    
    
    
    function getEventos(){
        
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT nombre, idEstado, codigoPostal, descripcion, direccion, fecha FROM Evento ORDER BY idEvento DESC';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html = '';
           $columnas = $results->fetch_fields();
           
           $i = 0;
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                
                    $html.='    <hr class="featurette-divider">
                                <div class="row featurette">
                                    <div class="col-md-7">
                                    <h2 class="featurette-heading">'.$fila["nombre"].'</span></h2>
                                    <p class="lead">'.$fila["descripcion"].'</p>
                                    
                                    <h4><span class="text-muted">Direccion:</span></h4>
                                    <p class="lead">'.$fila["direccion"].'</p>
                                    
                                    <h4><span class="text-muted">Código Postal:</span></h4>
                                    <p class="lead">'.$fila["codigoPostal"].'</p>
                                    
                                    <h4><span class="text-muted">Fecha:</span></h4>
                                    <p class="lead">'.$fila["fecha"].'</p>
                                    
                                  </div>
                                  <div class="col-md-5">
                                    <img class="featurette-image img-fluid mx-auto" src="/img/eevee.jpg" alt="Generic placeholder image">
                                  </div>
                                </div>
                    ';
                                                
                    
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    
    
    
    
    
    
    function agregaMaterial(){
        
        $nombre=$_GET["nombreMaterial"];
        $descripcion=$_GET["descripcionMaterial"];
        
        $db = connect();
        if ($db != NULL) {
            // insert command specification 
            $query='INSERT INTO Material (nombre, descripcion) VALUES (?,?) ';
            // Preparing the statement 
            if (!($statement = $db->prepare($query))) {
                die("Preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params 
            if (!$statement->bind_param("ss", $nombre, $descripcion)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error); 
            }
             // Executing the statement
             if (!$statement->execute()) {
                die("Execution failed: (" . $statement->errno . ") " . $statement->error);
              }
            
            mysqli_free_result($results);
            disconnect($db);
            return true;
        } 
        return false;
    }
    
    
    
    function getMateriales(){
        
        $db = connect();
        if ($db != NULL) {
        
            $query='SELECT * FROM Material';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '<div class="container">
                        <h2>Consulta de Materiales disponibles:</h2>
                        <br><br><hr>';
           $columnas = $results->fetch_fields();
           
           $i = 0;
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                
                        $html .= '<h4>Nombre:</h4>';
                        $html .= '<h6>'.$fila["nombre"].'<h6>'; 
                        $html .= '<br>'; 
                
                        $html .= '<h4>Descripción</h4>';
                        $html .= '<h6>'.$fila["descripcion"].'</h6>';
                        $html .= ' <form action="eliminarMaterial.php" method="GET">
                                    <br>
                                    <a class="btn btn-danger" role="button" href="#" data-href="/eliminarMaterial.php?id='.$fila["idMaterial"].'" data-toggle="modal" data-target="#delete-material" data-whatever="'.$fila["nombre"].'">Eliminar</a>
                                    </form>';
                        $html .= '<br>';
                        
                        $html .='<hr>';
                
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    
        
    }
    
    
    /* Elimina un material dado, ir a "_materiales.html" para detalles con jqwerty y ahaks*/
    function eliminarMaterial($id){
        $db = connect();
        if ($db != NULL) {
            // Deletion query construction
            //$query='UPDATE Material SET nombre="Eliminado", descripcion="Eliminado" WHERE idMaterial=?';
            $query = 'DELETE FROM Material WHERE idMaterial=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $id)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // delete execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    function getRSINST(){
        
        $db = connect();
        if ($db != NULL) {
        
            $query='SELECT * FROM Institucion';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '';
           
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                
                        $html .= '<option value="'.$fila["rfc"].'">'.$fila["razonSocial"].'</option>';
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    function getNombreMateriales(){
        
        $db = connect();
        if ($db != NULL) {
        
            $query='SELECT * FROM Material';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '';
           
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                
                        $html .= '<option value="'.$fila["idMaterial"].'">'.$fila["nombre"].'</option>';
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    
    function registrarReciclaje($insti, $mater, $canti) {
        $db = connect();
        if ($db != NULL) {
            // insert command specification 
            $query='INSERT INTO Institucion_Material (rfc, idMaterial, cantidad) VALUES (?,?,?) ';
            // Preparing the statement 
            if (!($statement = $db->prepare($query))) {
                die("Preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params 
            if (!$statement->bind_param("sss", $insti, $mater, $canti)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error); 
            }
             // Executing the statement
             if (!$statement->execute()) {
                die("Execution failed: (" . $statement->errno . ") " . $statement->error);
              }
            
            mysqli_free_result($results);
            disconnect($db);
            return true;
        } 
        return false;
    }
    
    
     function getEstados(){
        
        $db = connect();
        if ($db != NULL) {
        
            $query='SELECT * FROM Estado';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '';
           
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                
                        $html .= '<option value="'.$fila["idEstado"].'">'.$fila["Nombre"].'</option>';
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    function registrarInstitucion($rfc, $rs, $desc, $est, $cp) {
        $db = connect();
        if ($db != NULL) {
            // insert command specification 
            $logo = "logo.png";
            $query='INSERT INTO Institucion (rfc, razonSocial, descripcion, idEstado, codigoPostal, enlaceLogo) VALUES (?,?,?,?,?,?) ';
            // Preparing the statement 
            if (!($statement = $db->prepare($query))) {
                die("Preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params 
            if (!$statement->bind_param("ssssss", $rfc, $rs, $desc, $est, $cp, $logo)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error); 
            }
             // Executing the statement
             if (!$statement->execute()) {
                die("Execution failed: (" . $statement->errno . ") " . $statement->error);
              }
            
            mysqli_free_result($results);
            disconnect($db);
            return true;
        } 
        return false;
    }
    
    
    function getInstituciones() {
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT * FROM Institucion';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
            $html = '';
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    $html.= '<div class="col-lg-4">
                    
            <div class="card" style="background-color:#eceff1">
            
            <div class="card-body">

            <center><img class="rounded-circle" src="data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" alt="Generic placeholder image" width="140" height="140"></center>

            <h2>'.$fila["razonSocial"].'</h2>

            <p>'.$fila["descripcion"].'</p>

            <p><a class="btn btn-secondary" role="button" href="verInstitucion.php?idPage=1&rfc='.$fila["rfc"].'&rs='.$fila["razonSocial"].'&est='.$fila["idEstado"].'&cp='.$fila["codigoPostal"].'">Ver detalles &raquo;</a></p>

          </div><!-- /.col-lg-4 -->
          </div>
          </div>';
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    
function getSuma(){
        
        $db = connect();
        if ($db != NULL) {
        
            $query='SELECT SUM(cantidad) as "Total" FROM Institucion_Material';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '';
           
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                
                        $html .= ''.$fila["Total"].' Kg';
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    function getRegistros(){
        $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT * FROM Institucion_Material ORDER BY fecha DESC';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '<div class="container">
                        <h2>Últimas Entregas</h2>
                        <p>Listado de registros de entrega</p>            
                        <table class="table table-striped">
                            <thead>
                                <tr>';
           $columnas = $results->fetch_fields();
           /*
           for($i=0; $i<count($columnas); $i++) {
                $html .= '<th>'.$columnas[$i]->name.'</th>';
           }
           */
           $html .= '<th>RFC</th>';
           $html .= '<th>ID Material</th>';
           $html .= '<th>Cantidad</th>';
           $html .= '<th>Fecha</th>';
           $html .= '</tr>';
           $html .= '</thead>';
           $html .= '<tbody>';
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    $html .= '<tr>';
                    $html .= '<td>'.$fila["rfc"].'</td>'; 
                    $html .= '<td>'.$fila["idMaterial"].'</td>';
                    $html .= '<td>'.$fila["cantidad"].'</td>';
                    $html .= '<td>'.$fila["fecha"].'</td>';
                    $html .= '</tr>';
            }
            $html .= '</tbody></table></div>';   
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    //obtiene un material específico según su id
    function getMaterialEsp($nombreMaterial){
         $db = connect();
        if ($db != NULL) {
            
            //Specification of the SQL query
            $query='SELECT * FROM Material WHERE ="'.$idEvento.'"';
            $query;
             // Query execution; returns identifier of the result group
            $results = $db->query($query);
             // cycle to explode every line of the results
           $html =  '<div class="container">
                        <h2>Consulta de Evento:</h2>
                        <p>Detalles y especificaciones del evento</p>            
                        <br><br>';
           $columnas = $results->fetch_fields();
           /*
           for($i=0; $i<count($columnas); $i++) {
                $html .= '<th>'.$columnas[$i]->name.'</th>';
           }
           */
           $i = 0;
           while ($fila = mysqli_fetch_array($results, MYSQLI_BOTH)) {
                                                // Options: MYSQLI_NUM to use only numeric indexes
                                                // MYSQLI_ASSOC to use only name (string) indexes
                                                // MYSQLI_BOTH, to use both
                    for ($i = 0; $i < 6; $i++)  {
                        if ($i == 0){
                            $html .= '<h4>Evento</h4>';
                            $html .= '<h6>'.$fila["nombre"].'<h6>'; 
                            $html .= '<br>'; 
                        }
                        if ($i == 1){
                            $html .= '<h4>Estado</h4>';
                            $html .= '<h6>'.getNombreEstado($fila["idEstado"]).'</h6>';
                            $html .= '<br>'; 
                        }
                        if ($i == 2){
                            $html .= '<h4>Código Postal</h4>';
                            $html .= '<h6>'.$fila["codigoPostal"].'</h6>';
                            $html .= '<br>'; 
                        }
                        if ($i == 3){
                            $html .= '<h4>Dirección</h4>';
                            $html .= '<h6>'.$fila["direccion"].'</h6>';
                            $html .= '<br>'; 
                        }
                        if ($i == 4){
                            $html .= '<h4>Descripción</h4>';
                            $html .= '<h6>'.$fila["descripcion"].'</h6>';
                            $html .= '<br>'; 
                        }
                        if ($i == 5){
                            $html .= '<h4>Fecha</h4>';
                            $html .= '<h6>'.$fila["fecha"].'</h6>';
                            $html .= '<br>'; 
                        }
                    }
            }
            echo $html;
            // it releases the associated results
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    
    }
    
    function eliminarMembresia($user) {
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $query='UPDATE Usuario_Rol SET idRol=4 WHERE nUser=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $user)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            setActivo($user);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    function editarInstitucion($rfc, $rs, $desc, $estado, $cp){
        $db = connect();
        if ($db != NULL) {
            // update command specification
            $query='UPDATE Institucion SET razonSocial=?, descripcion=?, idEstado=?, codigoPostal=? WHERE rfc=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("sssss", $rs, $desc, $estado, $cp, $rfc)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // update execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    function eliminarInstitucion($rfc) {
        $db = connect();
        if ($db != NULL) {
            // Deletion query construction
            $query='UPDATE Institucion SET razonSocial="Eliminado", descripcion="", idEstado="9999", codigoPostal="00000" WHERE rfc=?';
            //$query = 'DELETE FROM Material WHERE idMaterial=?';
            if (!($statement = $db->prepare($query))) {
                die("The preparation failed: (" . $db->errno . ") " . $db->error);
            }
            // Binding statement params
            if (!$statement->bind_param("s", $rfc)) {
                die("Parameter vinculation failed: (" . $statement->errno . ") " . $statement->error);
            } 
            // delete execution
            if ($statement->execute()) {
                echo 'There were ' . mysqli_affected_rows($db) . ' affected rows';
            } else {
                die("Update failed: (" . $statement->errno . ") " . $statement->error);
            }
            mysqli_free_result($results);
            disconnect($db);
            return true;
        }
        return false;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

?>
