<?php
    session_start();
    require_once("modelo.php");
    if(isset($_SESSION["usuario"]) ) {
        if(isset($_GET["id"]) != NULL ) {
            unset($_SESSION["error_delete"]);
            eliminarMembresia($_GET["id"]);
            header("location:perfil.php?idPage=7");
        } else {
            $_SESSION["error_delete"] = "No se pudo completar el cambio";
            header("location:perfil.php?idPage=7");
        }
    } else {
        header("location:indexLogin.php");
    }
?>