<?php
    session_start();
    require_once("modelo.php");
    if(isset($_POST["username"]) != NULL ) {
        unset($_SESSION["error"]);
        unset($_SESSION["errorActivo"]);
        unset($_SESSION["error_password"]);
        if (getUsuario($_POST["username"])){
            //enviarPassword($_POST["username"]);
            $_SESSION["correct_password"] = "El correo electrónico se ha enviado exitosamente";
            header("location: ingresar.php");
        }
        else {
            unset($_SESSION["error"]);
            unset($_SESSION["errorActivo"]);
            unset($_SESSION["correct_password"]);
            $_SESSION["error_password"] = "El nombre de usuario ingresado no existe, no se pudo enviar un correo electrónico";
            header("location: ingresar.php");
        }
    }
?>