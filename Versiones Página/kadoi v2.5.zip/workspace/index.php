<?php
    session_start();
    if(isset($_SESSION["usuario"]) ) {
        header("location: login.php");    
    } else {
        $user = "";
        if (isset($_SESSION["error"]) != ""){
            unset($_SESSION["error"]);    
        }
        if (isset($_SESSION["errorActivo"]) != "") {
            unset($_SESSION["errorActivo"]);   
        }
        include("_header.html");
        include("_cuerpo.html");
        include("_footer.html");
    }
?>