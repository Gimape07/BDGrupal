<?php
    session_start();
    require_once("modelo.php");
    if(isset($_SESSION["usuario"]) ) {
        if(isset($_GET["id"]) != NULL ) {
            unset($_SESSION["error_delete"]);
            eliminarCapsula($_GET["id"]);
            header("location:capsula.php?idPage=3&cPage=1");
        } else {
            $_SESSION["error_delete"] = "No se pudo completar el cambio";
            header("location:capsula.php?idPage=3&cPage=1");
        }
    } else {
        header("location:indexLogin.php");
    }
?>